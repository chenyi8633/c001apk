package com.zailinn.c001apk.wear

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.zailinn.c001apk.core.model.Datum
import com.zailinn.c001apk.core.model.LoadResult
import com.zailinn.c001apk.core.model.cursorFirstId
import com.zailinn.c001apk.core.model.cursorLastId
import com.zailinn.c001apk.core.net.Page
import kotlinx.coroutines.CancellationException

/** A list that loads page after page, with the same cursors the phone app uses. */
class PagedFeed(private val load: suspend (Page) -> LoadResult<List<Datum>>) {
    var items by mutableStateOf<List<Datum>>(emptyList())
        private set
    var error by mutableStateOf<String?>(null)
        private set
    var ended by mutableStateOf(false)
        private set

    /** Counts finished loads, so the screen knows when to ask for the next page. */
    var loadedPages by mutableIntStateOf(0)
        private set

    private var loading = false
    private var page = 1
    private var first: String? = null
    private var last: String? = null

    suspend fun loadNext() {
        if (loading || ended) return
        loading = true
        error = null
        try {
            when (val result = load(Page(page, first, last))) {
                is LoadResult.Success -> {
                    val fresh = result.value
                    if (page == 1) first = fresh.cursorFirstId
                    last = fresh.cursorLastId ?: last
                    page++
                    items = (items + fresh).distinctBy { it.entityId ?: it.id ?: it.hashCode().toString() }
                }
                LoadResult.Empty -> ended = true
                is LoadResult.Error -> error = result.message
                LoadResult.Loading -> Unit
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            error = e.message ?: "加载失败"
        } finally {
            loading = false
            loadedPages++
        }
    }
}
