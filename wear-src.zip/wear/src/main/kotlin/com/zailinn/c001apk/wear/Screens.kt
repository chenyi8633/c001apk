package com.zailinn.c001apk.wear

import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.painter.ColorPainter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.wear.compose.foundation.lazy.ScalingLazyColumn
import androidx.wear.compose.foundation.lazy.ScalingLazyListState
import androidx.wear.compose.foundation.lazy.items
import androidx.wear.compose.foundation.lazy.rememberScalingLazyListState
import androidx.wear.compose.material3.Button
import androidx.wear.compose.material3.Card
import androidx.wear.compose.material3.ListHeader
import androidx.wear.compose.material3.MaterialTheme
import androidx.wear.compose.material3.ScreenScaffold
import androidx.wear.compose.material3.Text
import coil3.compose.AsyncImage
import com.zailinn.c001apk.core.model.Datum
import com.zailinn.c001apk.core.model.LoadResult
import kotlinx.coroutines.launch

private fun key(item: Datum): String = item.entityId ?: item.id ?: item.hashCode().toString()

@Composable
fun HomeScreen(
    feed: PagedFeed,
    listState: ScalingLazyListState,
    onOpen: (Datum) -> Unit,
    onAbout: () -> Unit,
) {
    // Filtered once per change of the list, not on every redraw.
    val cards = remember(feed.items) { feed.items.filter { it.entityType == "feed" } }

    // Ask for the next page a little before the end is reached, so scrolling never waits.
    LaunchedEffect(listState, cards.size) {
        snapshotFlow { listState.centerItemIndex }.collect { index ->
            if (cards.isNotEmpty() && index >= cards.size - 2) feed.loadNext()
        }
    }

    ScreenScaffold(scrollState = listState) { padding ->
        ScalingLazyColumn(
            modifier = Modifier.fillMaxSize(),
            state = listState,
            contentPadding = padding,
        ) {
            item { ListHeader { Text("酷安") } }
            items(cards, key = { key(it) }) { feedItem ->
                FeedCard(feedItem) { onOpen(feedItem) }
            }
            item { ListFooter(feed) }
            item {
                Button(
                    onClick = onAbout,
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("关于") },
                )
            }
        }
    }
}

@Composable
fun FeedCard(feed: Datum, onClick: () -> Unit) {
    // Text is worked out once per item; scrolling back over a card costs nothing.
    val text = remember(feed) {
        feed.string("message_title")?.takeIf { it.isNotBlank() } ?: plainText(feed.text("message"))
    }
    val meta = remember(feed) {
        "${relativeTime(feed.dateline)} · 赞${feed.string("likenum") ?: "0"} · 评${feed.string("replynum") ?: "0"}"
    }
    Card(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Text(
            feed.displayName,
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.primary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        Text(
            text.ifBlank { "[图片动态]" },
            style = MaterialTheme.typography.bodySmall,
            maxLines = 4,
            overflow = TextOverflow.Ellipsis,
        )
        Text(
            meta,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

/** A soft breathing text for loading states. The fade runs in the draw phase, so it never re-composes. */
@Composable
private fun PulsingText(text: String) {
    val transition = rememberInfiniteTransition(label = "pulse")
    val alpha by transition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(durationMillis = 800), RepeatMode.Reverse),
        label = "pulseAlpha",
    )
    Text(
        text,
        style = MaterialTheme.typography.labelSmall,
        modifier = Modifier.graphicsLayer { this.alpha = alpha },
    )
}

/** Loads the next page when it scrolls into view; shows errors with a retry button. */
@Composable
fun ListFooter(feed: PagedFeed) {
    val scope = rememberCoroutineScope()
    val error = feed.error
    when {
        error != null -> Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(error, style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Center, maxLines = 3)
            Button(
                onClick = { scope.launch { feed.loadNext() } },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("重试") },
            )
        }
        feed.ended -> Text("没有更多了", style = MaterialTheme.typography.labelSmall)
        else -> {
            LaunchedEffect(feed.loadedPages) { feed.loadNext() }
            PulsingText("加载中…")
        }
    }
}

@Composable
fun DetailScreen(container: WearContainer, initial: Datum) {
    var feed by remember(initial) { mutableStateOf(initial) }
    val id = initial.id ?: initial.entityId.orEmpty()

    // The list copy is shown at once; the full text replaces it when it arrives.
    LaunchedEffect(id) {
        val result = container.repository.feedDetail(id)
        if (result is LoadResult.Success) feed = result.value
    }
    val replies = remember(id) {
        PagedFeed { page -> container.repository.feedRepliesWithoutPrompt(id, "lastupdate_desc", page).result }
    }
    val listState = rememberScalingLazyListState()
    val body = remember(feed) { plainText(feed.text("message")).ifBlank { feed.messageTitle.orEmpty() } }
    val images = remember(feed) { feed.picArr.take(3).map(::thumbnail) }
    val counts = remember(feed) {
        "${relativeTime(feed.dateline)} · 赞${feed.string("likenum") ?: "0"} · 评${feed.string("replynum") ?: "0"}"
    }
    val replyCards = remember(replies.items) { replies.items.filter { it.entityType == "feed_reply" } }
    val placeholder = ColorPainter(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.15f))

    ScreenScaffold(scrollState = listState) { padding ->
        ScalingLazyColumn(
            modifier = Modifier.fillMaxSize(),
            state = listState,
            contentPadding = padding,
        ) {
            item {
                ListHeader {
                    Text(feed.displayName, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
            item {
                Text(
                    body.ifBlank { "[图片动态]" },
                    style = MaterialTheme.typography.bodySmall,
                    // Grows smoothly when the full text replaces the preview.
                    modifier = Modifier.fillMaxWidth().animateContentSize(),
                )
            }
            items(images) { url ->
                AsyncImage(
                    model = url,
                    contentDescription = null,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(100.dp)
                        .clip(RoundedCornerShape(12.dp)),
                    contentScale = ContentScale.Crop,
                    placeholder = placeholder,
                    error = placeholder,
                )
            }
            item {
                Text(
                    counts,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            item { ListHeader { Text("评论") } }
            items(replyCards, key = { key(it) }) { reply ->
                ReplyCard(reply)
            }
            item { ListFooter(replies) }
        }
    }
}

@Composable
private fun ReplyCard(reply: Datum) {
    val text = remember(reply) { plainText(reply.text("message")).ifBlank { "[图片]" } }
    Card(onClick = {}, modifier = Modifier.fillMaxWidth()) {
        Text(
            reply.displayName,
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.primary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        Text(
            text,
            style = MaterialTheme.typography.bodySmall,
            maxLines = 6,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

@Composable
fun AboutScreen() {
    val listState = rememberScalingLazyListState()
    ScreenScaffold(scrollState = listState) { padding ->
        ScalingLazyColumn(
            modifier = Modifier.fillMaxSize(),
            state = listState,
            contentPadding = padding,
        ) {
            item { ListHeader { Text("关于") } }
            item {
                Text(
                    "酷安 手表版 0.2\n游客模式：可以浏览首页动态和热门评论。手表上不能打开网页，所以登录、验证码、发帖暂不支持。",
                    style = MaterialTheme.typography.bodySmall,
                    textAlign = TextAlign.Center,
                )
            }
        }
    }
}
