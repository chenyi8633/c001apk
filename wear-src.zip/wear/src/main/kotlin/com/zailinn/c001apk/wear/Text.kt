package com.zailinn.c001apk.wear

import android.text.Html
import android.util.LruCache
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val plainCache = LruCache<String, String>(300)

/** The server sends HTML in messages; the watch shows plain text. Results are cached, since lists re-draw often. */
fun plainText(html: String): String {
    if (html.isEmpty()) return ""
    plainCache.get(html)?.let { return it }
    val result = runCatching {
        Html.fromHtml(html.replace("\n", "<br>"), Html.FROM_HTML_MODE_LEGACY).toString()
    }.getOrDefault(html.replace(Regex("<[^>]*>"), ""))
        .replace('\uFFFC', ' ')
        .trim()
    plainCache.put(html, result)
    return result
}

/** Server-side thumbnail: far less data than the original, which is plenty for a watch. */
fun thumbnail(url: String): String {
    val full = if (url.startsWith("//")) "https:$url" else url
    return if (full.endsWith(".s.jpg")) full else "$full.s.jpg"
}

fun relativeTime(seconds: Long?): String {
    if (seconds == null) return ""
    val diff = System.currentTimeMillis() / 1000 - seconds
    return when {
        diff < 60 -> "刚刚"
        diff < 3600 -> "${diff / 60}分钟前"
        diff < 86400 -> "${diff / 3600}小时前"
        diff < 86400 * 30 -> "${diff / 86400}天前"
        else -> SimpleDateFormat("yyyy-MM-dd", Locale.CHINA).format(Date(seconds * 1000))
    }
}
