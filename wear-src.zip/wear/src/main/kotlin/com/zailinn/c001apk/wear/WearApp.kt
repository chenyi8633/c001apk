package com.zailinn.c001apk.wear

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.wear.compose.foundation.lazy.rememberScalingLazyListState
import androidx.wear.compose.material3.AppScaffold
import androidx.wear.compose.material3.MaterialTheme
import androidx.wear.compose.navigation.SwipeDismissableNavHost
import androidx.wear.compose.navigation.composable
import androidx.wear.compose.navigation.rememberSwipeDismissableNavController
import com.zailinn.c001apk.core.model.Datum

@Composable
fun WearApp(container: WearContainer) {
    MaterialTheme {
        AppScaffold {
            val navController = rememberSwipeDismissableNavController()
            // Kept above the navigation host so going back does not reload or lose the scroll position.
            val homeFeed = remember {
                PagedFeed { page -> container.repository.homeFeed(page, 1, container.installTime) }
            }
            val homeListState = rememberScalingLazyListState()
            var selected by remember { mutableStateOf<Datum?>(null) }

            SwipeDismissableNavHost(navController = navController, startDestination = "home") {
                composable("home") {
                    HomeScreen(
                        feed = homeFeed,
                        listState = homeListState,
                        onOpen = {
                            selected = it
                            navController.navigate("detail")
                        },
                        onAbout = { navController.navigate("about") },
                    )
                }
                composable("detail") {
                    selected?.let { DetailScreen(container, it) }
                }
                composable("about") {
                    AboutScreen()
                }
            }
        }
    }
}
