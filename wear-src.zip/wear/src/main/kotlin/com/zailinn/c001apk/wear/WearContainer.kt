package com.zailinn.c001apk.wear

import android.content.Context
import com.zailinn.c001apk.core.net.CoolapkClient
import com.zailinn.c001apk.core.net.CoolapkHeaders
import com.zailinn.c001apk.core.net.CoolapkRepository
import com.zailinn.c001apk.core.net.SessionState
import com.zailinn.c001apk.core.protocol.ProtocolParams
import okhttp3.OkHttpClient

/** Everything the watch app shares: the phone app's network layer, in guest mode. */
class WearContainer(context: Context) {
    private val prefs = context.getSharedPreferences("wear", Context.MODE_PRIVATE)
    private val protocol: ProtocolParams = loadProtocol()

    val installTime: String = prefs.getString("installTime", null)
        ?: System.currentTimeMillis().toString().also { prefs.edit().putString("installTime", it).apply() }

    val session = SessionState()
    private val baseHttp = OkHttpClient()

    /** Images only get the client user agent, never API credentials. */
    val imageHttp: OkHttpClient = baseHttp.newBuilder()
        .addInterceptor { chain ->
            chain.proceed(chain.request().newBuilder().header("User-Agent", protocol.userAgent).build())
        }
        .build()

    val client = CoolapkClient(session, CoolapkHeaders(session, { protocol }), baseHttp)
    val repository = CoolapkRepository(client)

    private fun loadProtocol(): ProtocolParams {
        val device = prefs.getString("xAppDevice", null)
        if (device != null) {
            return ProtocolParams(
                manufacturer = prefs.getString("manufacturer", "").orEmpty(),
                brand = prefs.getString("brand", "").orEmpty(),
                model = prefs.getString("model", "").orEmpty(),
                buildNumber = prefs.getString("buildNumber", "").orEmpty(),
                sdkInt = prefs.getString("sdkInt", "").orEmpty(),
                androidVersion = prefs.getString("androidVersion", "").orEmpty(),
                userAgent = prefs.getString("userAgent", "").orEmpty(),
                xAppDevice = device,
            )
        }
        val fresh = ProtocolParams.generate()
        prefs.edit()
            .putString("manufacturer", fresh.manufacturer)
            .putString("brand", fresh.brand)
            .putString("model", fresh.model)
            .putString("buildNumber", fresh.buildNumber)
            .putString("sdkInt", fresh.sdkInt)
            .putString("androidVersion", fresh.androidVersion)
            .putString("userAgent", fresh.userAgent)
            .putString("xAppDevice", fresh.xAppDevice)
            .apply()
        return fresh
    }
}
